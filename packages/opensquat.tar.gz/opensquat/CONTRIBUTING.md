This is an openproject project under GPLv3 licensing, everyone is welcome to contribute! 

Please keep code compliant with PEP8

Happy coding :-)
