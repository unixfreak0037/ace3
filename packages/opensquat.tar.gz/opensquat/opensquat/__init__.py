# -*- coding: utf-8 -*-
# Module: __init__.py
"""openSquat Version."""
__VERSION__ = "1.97"
